import Test.QuickCheck
----------- Side effects - debugging pure functions

-- f :: Float -> Float
-- f x = x + 1

-- g :: Float -> Float
-- g x = x * 2

-- f' :: Float -> (Float,String)
-- f' x = (x + 1,"f was called.")

-- g' :: Float -> (Float,String)
-- g' x = (x * 2, "g was called.")

    
-- bind :: (Float -> (Float,String)) -> ((Float,String) -> (Float,String))
-- bind f = (\(xg,sg) -> (fst (f xg), sg ++ snd (f xg)))

-- unit :: Float -> (Float,String)
-- unit x = (x,"")

-- lift :: (Float -> Float) -> (Float -> (Float,String))
-- lift f = unit . f

-- testEquality :: Float -> Bool
-- testEquality x = ((bind (lift f)).(lift g)) x == (lift (f.g)) x

----------- A Container : Multivalued functions

-- data Complex a = a :+ a
--     deriving (Show, Eq)

-- f :: Complex Double -> Complex Double
-- f (x :+ y) = (x+1) :+ (y+1)

-- g :: Complex Double -> Complex Double
-- g (x :+ y) = (x * 2) :+ (y * 2)


-- bind :: (Complex Double -> [Complex Double]) -> ([Complex Double] -> [Complex Double])
-- bind f = (\listG -> concat [f lg| lg <- listG])

-- unit :: Complex Double -> [Complex Double]
-- unit c = [c]

-- lift :: (Complex Double -> Complex Double) -> (Complex Double -> [Complex Double])
-- lift f = unit . f

-- testEquality :: Double -> Bool
-- testEquality x = ((bind (lift f)).(lift g)) (x :+ x) == (lift (f.g)) (x :+ x)

------------- 
type Logger = String -> (Int,String)


test :: Num a => (a -> Logger) -> (Logger -> String)
test f x s = 




